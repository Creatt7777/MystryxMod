/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.LenientJsonParser;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public record Ops(Set<String> ops) {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static Ops parse(String json) {
        HashSet<String> ops = new HashSet<String>();
        try {
            JsonObject jsonObject = LenientJsonParser.parse(json).getAsJsonObject();
            JsonElement opsArray = jsonObject.get("ops");
            if (opsArray.isJsonArray()) {
                for (JsonElement opsElement : opsArray.getAsJsonArray()) {
                    ops.add(opsElement.getAsString());
                }
            }
        } catch (Exception e) {
            LOGGER.error("Could not parse Ops", e);
        }
        return new Ops(ops);
    }
}

