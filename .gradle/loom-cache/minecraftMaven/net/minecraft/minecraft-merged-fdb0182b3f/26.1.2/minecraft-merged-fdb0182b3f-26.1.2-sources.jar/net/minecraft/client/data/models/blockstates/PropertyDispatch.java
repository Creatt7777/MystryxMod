/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.data.models.blockstates;

import com.mojang.datafixers.util.Function3;
import com.mojang.datafixers.util.Function4;
import com.mojang.datafixers.util.Function5;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.data.models.MultiVariant;
import net.minecraft.client.data.models.blockstates.PropertyValueList;
import net.minecraft.client.renderer.block.dispatch.VariantMutator;
import net.minecraft.world.level.block.state.properties.Property;

@Environment(value=EnvType.CLIENT)
public abstract class PropertyDispatch<V> {
    private final Map<PropertyValueList, V> values = new HashMap<PropertyValueList, V>();

    protected void putValue(PropertyValueList key, V variant) {
        V previous = this.values.put(key, variant);
        if (previous != null) {
            throw new IllegalStateException("Value " + String.valueOf(key) + " is already defined");
        }
    }

    Map<PropertyValueList, V> getEntries() {
        this.verifyComplete();
        return Map.copyOf(this.values);
    }

    private void verifyComplete() {
        List<Property<?>> properties = this.getDefinedProperties();
        Stream<PropertyValueList> valuesToCover = Stream.of(PropertyValueList.EMPTY);
        for (Property<?> property : properties) {
            valuesToCover = valuesToCover.flatMap(current -> property.getAllValues().map(current::extend));
        }
        List<PropertyValueList> undefinedCombinations = valuesToCover.filter(f -> !this.values.containsKey(f)).toList();
        if (!undefinedCombinations.isEmpty()) {
            throw new IllegalStateException("Missing definition for properties: " + String.valueOf(undefinedCombinations));
        }
    }

    abstract List<Property<?>> getDefinedProperties();

    public static <T1 extends Comparable<T1>> C1<MultiVariant, T1> initial(Property<T1> property1) {
        return new C1(property1);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>> C2<MultiVariant, T1, T2> initial(Property<T1> property1, Property<T2> property2) {
        return new C2(property1, property2);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>> C3<MultiVariant, T1, T2, T3> initial(Property<T1> property1, Property<T2> property2, Property<T3> property3) {
        return new C3(property1, property2, property3);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>> C4<MultiVariant, T1, T2, T3, T4> initial(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4) {
        return new C4(property1, property2, property3, property4);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>, T5 extends Comparable<T5>> C5<MultiVariant, T1, T2, T3, T4, T5> initial(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4, Property<T5> property5) {
        return new C5(property1, property2, property3, property4, property5);
    }

    public static <T1 extends Comparable<T1>> C1<VariantMutator, T1> modify(Property<T1> property1) {
        return new C1(property1);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>> C2<VariantMutator, T1, T2> modify(Property<T1> property1, Property<T2> property2) {
        return new C2(property1, property2);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>> C3<VariantMutator, T1, T2, T3> modify(Property<T1> property1, Property<T2> property2, Property<T3> property3) {
        return new C3(property1, property2, property3);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>> C4<VariantMutator, T1, T2, T3, T4> modify(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4) {
        return new C4(property1, property2, property3, property4);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>, T5 extends Comparable<T5>> C5<VariantMutator, T1, T2, T3, T4, T5> modify(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4, Property<T5> property5) {
        return new C5(property1, property2, property3, property4, property5);
    }

    @Environment(value=EnvType.CLIENT)
    public static class C1<V, T1 extends Comparable<T1>>
    extends PropertyDispatch<V> {
        private final Property<T1> property1;

        private C1(Property<T1> property1) {
            this.property1 = property1;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return List.of(this.property1);
        }

        public C1<V, T1> select(T1 value1, V variants) {
            PropertyValueList key = PropertyValueList.of(this.property1.value(value1));
            this.putValue(key, variants);
            return this;
        }

        public PropertyDispatch<V> generate(Function<T1, V> generator) {
            this.property1.getPossibleValues().forEach(value1 -> this.select(value1, generator.apply(value1)));
            return this;
        }
    }

    @Environment(value=EnvType.CLIENT)
    public static class C2<V, T1 extends Comparable<T1>, T2 extends Comparable<T2>>
    extends PropertyDispatch<V> {
        private final Property<T1> property1;
        private final Property<T2> property2;

        private C2(Property<T1> property1, Property<T2> property2) {
            this.property1 = property1;
            this.property2 = property2;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return List.of(this.property1, this.property2);
        }

        public C2<V, T1, T2> select(T1 value1, T2 value2, V variants) {
            PropertyValueList key = PropertyValueList.of(this.property1.value(value1), this.property2.value(value2));
            this.putValue(key, variants);
            return this;
        }

        public PropertyDispatch<V> generate(BiFunction<T1, T2, V> generator) {
            this.property1.getPossibleValues().forEach(value1 -> this.property2.getPossibleValues().forEach(value2 -> this.select(value1, value2, generator.apply(value1, value2))));
            return this;
        }
    }

    @Environment(value=EnvType.CLIENT)
    public static class C3<V, T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>>
    extends PropertyDispatch<V> {
        private final Property<T1> property1;
        private final Property<T2> property2;
        private final Property<T3> property3;

        private C3(Property<T1> property1, Property<T2> property2, Property<T3> property3) {
            this.property1 = property1;
            this.property2 = property2;
            this.property3 = property3;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return List.of(this.property1, this.property2, this.property3);
        }

        public C3<V, T1, T2, T3> select(T1 value1, T2 value2, T3 value3, V variants) {
            PropertyValueList key = PropertyValueList.of(this.property1.value(value1), this.property2.value(value2), this.property3.value(value3));
            this.putValue(key, variants);
            return this;
        }

        public PropertyDispatch<V> generate(Function3<T1, T2, T3, V> generator) {
            this.property1.getPossibleValues().forEach(value1 -> this.property2.getPossibleValues().forEach(value2 -> this.property3.getPossibleValues().forEach(value3 -> this.select(value1, value2, value3, generator.apply(value1, value2, value3)))));
            return this;
        }
    }

    @Environment(value=EnvType.CLIENT)
    public static class C4<V, T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>>
    extends PropertyDispatch<V> {
        private final Property<T1> property1;
        private final Property<T2> property2;
        private final Property<T3> property3;
        private final Property<T4> property4;

        private C4(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4) {
            this.property1 = property1;
            this.property2 = property2;
            this.property3 = property3;
            this.property4 = property4;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return List.of(this.property1, this.property2, this.property3, this.property4);
        }

        public C4<V, T1, T2, T3, T4> select(T1 value1, T2 value2, T3 value3, T4 value4, V variants) {
            PropertyValueList key = PropertyValueList.of(this.property1.value(value1), this.property2.value(value2), this.property3.value(value3), this.property4.value(value4));
            this.putValue(key, variants);
            return this;
        }

        public PropertyDispatch<V> generate(Function4<T1, T2, T3, T4, V> generator) {
            this.property1.getPossibleValues().forEach(value1 -> this.property2.getPossibleValues().forEach(value2 -> this.property3.getPossibleValues().forEach(value3 -> this.property4.getPossibleValues().forEach(value4 -> this.select(value1, value2, value3, value4, generator.apply(value1, value2, value3, value4))))));
            return this;
        }
    }

    @Environment(value=EnvType.CLIENT)
    public static class C5<V, T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>, T5 extends Comparable<T5>>
    extends PropertyDispatch<V> {
        private final Property<T1> property1;
        private final Property<T2> property2;
        private final Property<T3> property3;
        private final Property<T4> property4;
        private final Property<T5> property5;

        private C5(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4, Property<T5> property5) {
            this.property1 = property1;
            this.property2 = property2;
            this.property3 = property3;
            this.property4 = property4;
            this.property5 = property5;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return List.of(this.property1, this.property2, this.property3, this.property4, this.property5);
        }

        public C5<V, T1, T2, T3, T4, T5> select(T1 value1, T2 value2, T3 value3, T4 value4, T5 value5, V variants) {
            PropertyValueList key = PropertyValueList.of(this.property1.value(value1), this.property2.value(value2), this.property3.value(value3), this.property4.value(value4), this.property5.value(value5));
            this.putValue(key, variants);
            return this;
        }

        public PropertyDispatch<V> generate(Function5<T1, T2, T3, T4, T5, V> generator) {
            this.property1.getPossibleValues().forEach(value1 -> this.property2.getPossibleValues().forEach(value2 -> this.property3.getPossibleValues().forEach(value3 -> this.property4.getPossibleValues().forEach(value4 -> this.property5.getPossibleValues().forEach(value5 -> this.select(value1, value2, value3, value4, value5, generator.apply(value1, value2, value3, value4, value5)))))));
            return this;
        }
    }
}

